<?php
$conn=mysqli_connect("localhost","root","","department");
if($conn){
$insert="LOAD DATA LOCAL INFILE 'dpt_data.txt' INTO TABLE dpt_details(id,name,students);";
$result=mysqli_query($conn,$insert);
if($result){
	echo "inserted successfully";
}
else{
echo "Not inserted";
}
}
else{
echo "Not connected";

}
?>