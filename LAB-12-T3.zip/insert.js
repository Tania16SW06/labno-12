$(document).ready(function (e) {

$("#insert").click(function(e) {
e.preventDefault();
var fullName= $("#fullName").val();
var addressLine1= $("#addressLine1").val();
var addressLine2= $("#addressLine2").val();
var city= $("#city").val();
var country= $("#country").val();
var province= $("#province").val();
var email= $("#email").val();
var phoneNumber= $("#phoneNumber").val();
var postalCode= $("#postalCode").val();

$.ajax({    
     url: "insert.php", 
     type: "POST",                    
     data: {fullName:fullName,addressLine1:addressLine1,addressLine2:addressLine2,city:city,
        country:country,province:province,postalCode:postalCode,phoneNumber:phoneNumber,email:email},                                 
     success: function(data)         
     {
        
        $('#fullName').val("");
        $('#email').val("");
        $('#addressLine1').val("");
        $('#addressLine2').val("");
        $('#province').val("");
        $('#phoneNumber').val("");
        $('#postalCode').val("");
        $('#country').val("");
        $('#city').val("");
     	alert("Inserted successfully");
        //location.reload();
      },  //end success

    error: function(error) {

     console.log(error);
     alert (error);
     alert( JSON.stringify(error) );
    
  }
    });
  }); 
});