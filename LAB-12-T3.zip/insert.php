<?php
$fullName=$_POST['fullName'];
$addressLine1=$_POST['addressLine1'];
$addressLine2=$_POST['addressLine2'];
$email=$_POST['email'];
$phoneNumber=$_POST['phoneNumber'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$postalCode=$_POST['postalCode'];
if(isset($_POST['insert'])){
$conn=mysqli_connect("localhost","root","","Biodata");
if($conn){
	echo "Connected Successfully";
	$fullName=mysqli_real_escape_string($conn,$_POST['fullName']);
$addressLine1=mysqli_real_escape_string($conn,$_POST['addressLine1']);
$addressLine2=mysqli_real_escape_string($conn,$_POST['addressLine2']);
$email=mysqli_real_escape_string($conn,$_POST['email']);
$phoneNumber=mysqli_real_escape_string($conn,$_POST['phoneNumber']);
$province=mysqli_real_escape_string($conn,$_POST['province']);
$city=mysqli_real_escape_string($conn,$_POST['city']);
$country=mysqli_real_escape_string($conn,$_POST['country']);
$postalCode=mysqli_real_escape_string($conn,$_POST['postalCode']);
$insert="INSERT INTO Biodata(Full_Name,Address_Line1,Address_Line2,Email,Phone_Number,Postal_Code,Province,Country,City) VALUES ('$fullName','$addressLine1',
'$addressLine2','$email','$phoneNumber','$postalCode','$province','$country','$city')";
$result=mysqli_query($conn,$insert);
if($result){
	echo "Record inserted successfully";
}
else{
	echo "Not inserted";
	echo mysqli_error($result);
}
mysqli_close($conn);
}}
else{	echo "NoT CONNECTED";
}
?>